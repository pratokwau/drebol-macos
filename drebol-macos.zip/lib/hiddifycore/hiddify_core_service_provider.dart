import 'dart:async';

import 'package:hiddify/core/directories/directories_provider.dart';
import 'package:hiddify/core/notification/in_app_notification_controller.dart';
import 'package:hiddify/hiddifycore/hiddify_core_service.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:riverpod_annotation/riverpod_annotation.dart';

part 'hiddify_core_service_provider.g.dart';

@Riverpod(keepAlive: true, dependencies: [AppDirectories, inAppNotificationController])
HiddifyCoreService hiddifyCoreService(Ref ref) {
  final service = HiddifyCoreService(ref);
  ref.onDispose(() => unawaited(service.core.dispose()));
  return service;
}
