import 'package:hiddify/core/utils/proxy_secret.dart';
import 'package:hiddify/utils/utils.dart';
import 'package:shared_preferences/shared_preferences.dart';

class PreferencesMigration with InfraLogger {
  PreferencesMigration({required this.sharedPreferences});

  final SharedPreferences sharedPreferences;

  static const versionKey = "preferences_version";

  Future<void> migrate() async {
    final currentVersion = sharedPreferences.getInt(versionKey) ?? 0;

    final migrationSteps = <PreferencesMigrationStep>[
      PreferencesVersion1Migration(sharedPreferences),
      PreferencesVersion2Migration(sharedPreferences),
      PreferencesVersion3Migration(sharedPreferences),
      PreferencesVersion4Migration(sharedPreferences),
      PreferencesVersion5Migration(sharedPreferences),
    ];

    if (currentVersion == migrationSteps.length) {
      loggy.debug("already using the latest version (v$currentVersion)");
      return;
    }

    final stopWatch = Stopwatch()..start();
    loggy.debug("migrating from v[$currentVersion] to v[${migrationSteps.length}]");
    for (int i = currentVersion; i < migrationSteps.length; i++) {
      loggy.debug("step [$i](v${i + 1})");
      await migrationSteps[i].migrate();
      await sharedPreferences.setInt(versionKey, i + 1);
    }
    stopWatch.stop();
    loggy.debug("migration took [${stopWatch.elapsedMilliseconds}]ms");
  }
}

abstract interface class PreferencesMigrationStep {
  PreferencesMigrationStep(this.sharedPreferences);

  final SharedPreferences sharedPreferences;

  Future<void> migrate();
}

class PreferencesVersion1Migration extends PreferencesMigrationStep with InfraLogger {
  PreferencesVersion1Migration(super.sharedPreferences);

  @override
  Future<void> migrate() async {
    if (sharedPreferences.getString("service-mode") case final String serviceMode) {
      final newMode = switch (serviceMode) {
        "proxy" || "system-proxy" || "vpn" || "router" => serviceMode,
        "systemProxy" => "system-proxy",
        "tun" => "vpn",
        _ => PlatformUtils.isDesktop ? "system-proxy" : "vpn",
      };
      loggy.debug("changing service-mode from [$serviceMode] to [$newMode]");
      await sharedPreferences.setString("service-mode", newMode);
    }

    if (sharedPreferences.getString("ipv6-mode") case final String ipv6Mode) {
      loggy.debug("changing ipv6-mode from [$ipv6Mode] to [${_ipv6Mapper(ipv6Mode)}]");
      await sharedPreferences.setString("ipv6-mode", _ipv6Mapper(ipv6Mode));
    }

    if (sharedPreferences.getString("remote-domain-dns-strategy") case final String remoteDomainStrategy) {
      loggy.debug(
        "changing [remote-domain-dns-strategy] = [$remoteDomainStrategy] to [remote-dns-domain-strategy] = [${_domainStrategyMapper(remoteDomainStrategy)}]",
      );
      await sharedPreferences.remove("remote-domain-dns-strategy");
      await sharedPreferences.setString("remote-dns-domain-strategy", _domainStrategyMapper(remoteDomainStrategy));
    }

    if (sharedPreferences.getString("direct-domain-dns-strategy") case final String directDomainStrategy) {
      loggy.debug(
        "changing [direct-domain-dns-strategy] = [$directDomainStrategy] to [direct-dns-domain-strategy] = [${_domainStrategyMapper(directDomainStrategy)}]",
      );
      await sharedPreferences.remove("direct-domain-dns-strategy");
      await sharedPreferences.setString("direct-dns-domain-strategy", _domainStrategyMapper(directDomainStrategy));
    }

    if (sharedPreferences.getInt("localDns-port") case final int directPort) {
      loggy.debug("changing [localDns-port] to [direct-port]");
      await sharedPreferences.remove("localDns-port");
      await sharedPreferences.setInt("direct-port", directPort);
    }

    await sharedPreferences.remove("execute-config-as-is");
    await sharedPreferences.remove("enable-tun");
    await sharedPreferences.remove("set-system-proxy");

    await sharedPreferences.remove("cron_profiles_update");
  }

  /// IPv6 for the apps is off (ipv4_only) unless turned on; the retired "exclusive"/ipv6_only
  /// becomes the preference nearest it, and "enable" the IPv4-first one.
  String _ipv6Mapper(String persisted) => switch (persisted) {
    "ipv4_only" || "prefer_ipv4" || "prefer_ipv6" => persisted,
    "enable" => "prefer_ipv4",
    "prefer" || "only" || "ipv6_only" => "prefer_ipv6",
    _ => "ipv4_only",
  };

  String _domainStrategyMapper(String persisted) => switch (persisted) {
    "ipv4_only" || "prefer_ipv4" || "prefer_ipv4" || "ipv6_only" => persisted,
    "auto" => "",
    "preferIpv6" => "prefer_ipv6",
    "preferIpv4" => "prefer_ipv4",
    "ipv4Only" => "ipv4_only",
    "ipv6Only" => "ipv6_only",
    _ => "",
  };
}

/// App-based routing's switch gets its own key. Its mode used to be "off" while it was off, which is now taken as
/// never turned on.
class PreferencesVersion2Migration extends PreferencesMigrationStep with InfraLogger {
  PreferencesVersion2Migration(super.sharedPreferences);

  @override
  Future<void> migrate() async {
    if (sharedPreferences.getString("per_app_proxy_mode") case final String mode) {
      if (mode == "off") {
        loggy.debug("removing [per_app_proxy_mode] = [off]");
        await sharedPreferences.remove("per_app_proxy_mode");
      } else {
        loggy.debug("setting [per_app_proxy_enabled] for [per_app_proxy_mode] = [$mode]");
        await sharedPreferences.setBool("per_app_proxy_enabled", true);
      }
    }
  }
}

/// The unblocker's WARP clean IP chose the endpoint source as well: an address meant that address,
/// the words auto/default/random (and auto4/auto6) a scan. The source is its own preference now,
/// and the clean IP only the custom address.
class PreferencesVersion3Migration extends PreferencesMigrationStep with InfraLogger {
  PreferencesVersion3Migration(super.sharedPreferences);

  @override
  Future<void> migrate() async {
    const cleanIpKey = "unblocker-warp-clean-ip";
    const endpointKey = "unblocker-warp-endpoint";
    if (sharedPreferences.containsKey(endpointKey)) return;
    final cleanIp = sharedPreferences.getString(cleanIpKey)?.trim() ?? '';
    if (cleanIp.isEmpty) return;
    if (const ['auto', 'auto4', 'auto6', 'default', 'random'].contains(cleanIp.toLowerCase())) {
      loggy.debug("unblocker WARP clean ip [$cleanIp] was a scan");
      await sharedPreferences.setString(endpointKey, "scan");
      await sharedPreferences.remove(cleanIpKey);
    } else {
      loggy.debug("unblocker WARP clean ip [$cleanIp] is its custom endpoint");
      await sharedPreferences.setString(endpointKey, "custom");
    }
  }
}

/// The local SOCKS/HTTP port asks for a secret in proxy mode and from the local network, so every
/// install gets one; it was made only once LAN sharing was turned on.
class PreferencesVersion4Migration extends PreferencesMigrationStep with InfraLogger {
  PreferencesVersion4Migration(super.sharedPreferences);

  @override
  Future<void> migrate() async {
    const key = "lan_sharing_password";
    if ((sharedPreferences.getString(key) ?? '').isNotEmpty) return;
    loggy.debug("making the proxy secret");
    await sharedPreferences.setString(key, generateProxySecret());
  }
}

/// "Use xray-core when possible" is gone, so a value an older version saved is dropped.
class PreferencesVersion5Migration extends PreferencesMigrationStep with InfraLogger {
  PreferencesVersion5Migration(super.sharedPreferences);

  @override
  Future<void> migrate() async {
    await sharedPreferences.remove("use-xray-core-when-possible");
  }
}
