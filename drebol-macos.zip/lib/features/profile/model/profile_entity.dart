import 'dart:convert';
import 'dart:math';

import 'package:dartx/dartx.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:hiddify/features/profile/data/profile_parser.dart';

part 'profile_entity.freezed.dart';
part 'profile_entity.g.dart';

enum ProfileType { remote, local }

@freezed
sealed class ProfileEntity with _$ProfileEntity {
  const ProfileEntity._();

  const factory ProfileEntity.remote({
    required String id,
    required bool active,
    required String name,
    required String url,
    required DateTime lastUpdate,
    ProfileOptions? options,
    SubscriptionInfo? subInfo,
    // `profile-web-page-url` / `support-url` headers; independent of subInfo,
    // which only exists when the `subscription-userinfo` header is present.
    // Custom IP lookup uses `ipinfo-url` in [populatedHeaders] only.
    String? webPageUrl,
    String? supportUrl,
    Map<String, dynamic>? populatedHeaders,
    UserOverride? userOverride,
    @Default(false) bool pinned,
  }) = RemoteProfileEntity;

  const factory ProfileEntity.local({
    required String id,
    required bool active,
    required String name,
    required DateTime lastUpdate,
    Map<String, dynamic>? populatedHeaders,
    UserOverride? userOverride,
    @Default(false) bool pinned,
  }) = LocalProfileEntity;

  String profileOverride() =>
      ProfileParser.profileOverride(populatedHeaders: populatedHeaders, userOverride: userOverride);
}

@freezed
class ProfileOptions with _$ProfileOptions {
  const factory ProfileOptions({@Default(Duration.zero) Duration updateInterval}) = _ProfileOptions;
}

@freezed
class SubscriptionInfo with _$SubscriptionInfo {
  const SubscriptionInfo._();

  const factory SubscriptionInfo({
    required int upload,
    required int download,
    required int total,
    required DateTime expire,
  }) = _SubscriptionInfo;

  bool get isExpired => expire <= DateTime.now();

  int get consumption => upload + download;
  int get remainingBW => total - consumption;
  double get remainingBWratio => (remainingBW / total).clamp(0, 1);
  double get ratio => (consumption / total).clamp(0, 1);

  Duration get remaining => expire.difference(DateTime.now());
  double get remainingRatio => min(remaining.inDays, 30) / 30;
}

const int latestUserOverrideVersion = 3;

/// Per-profile preference for elevated admin_bgservice on Windows/Linux.
enum UserAdminPreference {
  /// Ask when optional admin is needed (Mode C).
  unset,

  /// Skip the dialog and use admin_bgservice.
  preferAdmin,

  /// Skip the dialog and continue without admin (strip privileged features).
  preferNoAdmin,
}

@freezed
abstract class UserOverride with _$UserOverride {
  const UserOverride._();

  const factory UserOverride({
    @Default(latestUserOverrideVersion) int version,
    String? name,
    @Default(false) bool isAutoUpdateDisable,
    // hours
    int? updateInterval,

    /// Single extra-security mode — `warp` or `psiphon`. They share one slot
    /// because the core runs one chain mode at a time, mirroring the
    /// `extra-security` subscription header.
    String? extraSecurity,

    /// Enables TLS fragmentation using the user's own configured size/sleep.
    /// Unlike the `fragment` subscription header it carries no values, since
    /// the user's settings already hold them.
    bool? enableFragment,

    /// How many of the profile's proxies run: the fastest of them by their first pings, the others
    /// stopped; -1 runs them all. Null until the user chose, and then the subscription's `keep-top`
    /// header decides, or the user is asked when the profile is big (see keep_top.dart).
    int? keepTop,

    /// Lets keep top pick the fastest before every proxy is tested: once the ones still to test
    /// were slower last time, and every one not tested in the last day has been. Null is on.
    bool? keepTopQuick,

    /// The countries keep top keeps proxies of (two-letter codes); null or empty for any.
    List<String>? keepTopCountries,

    /// The tags of the profile's proxies the user chose to run, and only them, whatever [keepTop]
    /// says, while any of them is still in the profile. Null until the user chose some.
    List<String>? keepTags,

    /// Windows/Linux: whether to prefer elevated admin_bgservice for privileged
    /// proxy features. Subscription sync must not overwrite this field.
    @Default(UserAdminPreference.unset) UserAdminPreference adminPreference,
  }) = _UserOverride;

  factory UserOverride.fromJson(Map<String, Object?> json) => _$UserOverrideFromJson(json);

  String toStr() => jsonEncode(toJson());

  static UserOverride? fromStr(String? str) {
    if (str != null) {
      final m = (jsonDecode(str) as Map).cast<String, Object?>();
      return UserOverride.fromJson(_migrate(m));
    }
    return null;
  }

  static Map<String, dynamic> _migrate(Map<String, Object?> json) {
    final version = json['version'] as int? ?? 1;

    if (version < 2) {
      // v1 -> v2: the `enableWarp` / `enablePsiphon` booleans become a single
      // `extraSecurity` mode, since only one chain mode can run. Psiphon wins
      // when both were on, matching v1 behaviour where it overrode warp.
      if (json.remove('enableWarp') == true) json['extraSecurity'] = 'warp';
      if (json.remove('enablePsiphon') == true) json['extraSecurity'] = 'psiphon';
    }
    // v2 -> v3: add adminPreference (defaults to unset).
    json['adminPreference'] ??= 'unset';
    json['version'] = latestUserOverrideVersion;
    return json;
  }
}
