import 'dart:convert';
import 'dart:io';

import 'package:fpdart/fpdart.dart';
import 'package:hiddify/core/localization/translations.dart';
import 'package:hiddify/core/model/directories.dart';
import 'package:hiddify/core/model/environment.dart';
import 'package:hiddify/core/notification/in_app_notification_controller.dart';
import 'package:hiddify/core/preferences/general_preferences.dart';
import 'package:hiddify/core/router/dialog/dialog_notifier.dart';
import 'package:hiddify/core/router/dialog/widgets/admin_bg_service_dialogs.dart';
import 'package:hiddify/core/utils/exception_handler.dart';
import 'package:hiddify/features/connection/model/connection_failure.dart';
import 'package:hiddify/features/connection/model/connection_status.dart';
import 'package:hiddify/features/profile/data/profile_data_providers.dart';
import 'package:hiddify/features/profile/data/profile_path_resolver.dart';
import 'package:hiddify/features/profile/model/profile_entity.dart';
import 'package:hiddify/features/settings/data/config_option_repository.dart';
import 'package:hiddify/hiddifycore/core_interface/admin_permission_refused.dart';
import 'package:hiddify/hiddifycore/core_interface/core_interface_desktop_tun.dart';
import 'package:hiddify/hiddifycore/core_interface/core_interface_macos.dart';
import 'package:hiddify/hiddifycore/generated/v2/hcore/hcore.pbenum.dart' as hcore;
import 'package:hiddify/hiddifycore/hiddify_core_service.dart';
import 'package:hiddify/singbox/model/core_status.dart';
import 'package:hiddify/singbox/model/singbox_config_enum.dart';
import 'package:hiddify/singbox/model/singbox_config_option.dart';
import 'package:hiddify/utils/utils.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:meta/meta.dart';

abstract interface class ConnectionRepository {
  SingboxConfigOption? get configOptionsSnapshot;

  TaskEither<ConnectionFailure, Unit> setup();
  Stream<ConnectionStatus> watchConnectionStatus();

  /// Whether the core is applying a new config without a restart; the connection stays up
  /// (watchConnectionStatus keeps reporting it as connected).
  TaskEither<ConnectionFailure, Unit> connect(ProfileEntity activeProfile, bool disableMemoryLimit);
  TaskEither<ConnectionFailure, Unit> disconnect();
  TaskEither<ConnectionFailure, Unit> reconnect(ProfileEntity activeProfile, bool disableMemoryLimit);
}

class ConnectionRepositoryImpl with ExceptionHandler, InfraLogger implements ConnectionRepository {
  ConnectionRepositoryImpl({
    required this.ref,
    required this.directories,
    required this.singbox,
    required this.configOptionRepository,
    required this.profilePathResolver,
  });

  final Ref ref;

  final Directories directories;
  final HiddifyCoreService singbox;

  final ConfigOptionRepository configOptionRepository;
  final ProfilePathResolver profilePathResolver;

  SingboxConfigOption? _configOptionsSnapshot;
  @override
  SingboxConfigOption? get configOptionsSnapshot => _configOptionsSnapshot;

  bool _initialized = false;

  @override
  TaskEither<ConnectionFailure, Unit> setup() {
    if (_initialized) return TaskEither.of(unit);
    return exceptionHandler(() {
      loggy.debug("setting up singbox");

      return singbox
          .setup()
          .map((r) {
            _initialized = true;
            return r;
          })
          .mapLeft(UnexpectedConnectionFailure.new)
          .run();
    }, UnexpectedConnectionFailure.new);
  }

  @override
  Stream<ConnectionStatus> watchConnectionStatus() {
    return singbox.watchStatus().map(
      (event) => switch (event) {
        CoreStopped() => Disconnected(event.getCoreAlert()),
        CoreStarting() => const Connecting(),
        CoreWaiting() => const Waiting(),
        CoreNoAvailableProxies() => const NoAvailableProxies(),
        CoreStarted() => const Connected(),
        CoreStopping() => const Disconnecting(),
        CoreHotReloading() => const HotReloading(),
      },
    );
  }

  /// Set while a connect runs: the VPN choice dialog was shown, and then the administrator prompt
  /// was refused or the user stopped waiting for it.
  var _vpnChoiceShown = false;
  var _adminRefused = false;

  /// Connects; when the user agreed to VPN mode in the choice dialog but then refused the
  /// administrator prompt (or stopped waiting for it), the choice is offered again instead of an
  /// error, so they can try again or switch to system proxy mode.
  @override
  TaskEither<ConnectionFailure, Unit> connect(ProfileEntity activeProfile, bool disableMemoryLimit) => setup().flatMap(
    (_) => TaskEither(() async {
      while (true) {
        _vpnChoiceShown = false;
        _adminRefused = false;
        final result = await _connectOnce(activeProfile, disableMemoryLimit).run();
        if (result.isRight() || !_vpnChoiceShown || !_adminRefused) return result;
        loggy.info("administrator permission was not given, offering the choice again");
      }
    }),
  );

  TaskEither<ConnectionFailure, Unit> _connectOnce(ProfileEntity activeProfile, bool disableMemoryLimit) =>
      applyConfigOption(activeProfile).flatMap(
        (_) =>
            TaskEither.tryCatch(() async {
              await _prepareAdminBgService(activeProfile);
              return unit;
            }, (err, st) => err is ConnectionFailure ? err : ConnectionFailure.unexpected(err, st)).flatMap(
              (_) => singbox.start(
                profilePathResolver.file(activeProfile.id).path,
                activeProfile.name,
                disableMemoryLimit,
              ),
            ),
      );

  /// Modes A/B/C: ask fg core (Win/Linux) or native tunnel-service status (macOS), show consent.
  Future<void> _prepareAdminBgService(ProfileEntity profile) async {
    final options = _configOptionsSnapshot;
    if (options == null) return;

    if (Platform.isMacOS) {
      await _prepareMacosAdminBgService(profile, options);
      return;
    }
    if (!Platform.isWindows && !Platform.isLinux) return;
    final core = singbox.core;
    if (core is! CoreInterfaceDesktopTun) return;

    final pref = profile.userOverride?.adminPreference ?? UserAdminPreference.unset;
    final serviceMode = _serviceMode(options);

    final decision = await core.needAdminBgService(
      serviceMode: serviceMode,
      settingsJson: jsonEncode(options.toJson()),
      adminPreference: switch (pref) {
        UserAdminPreference.unset => hcore.AdminPreference.ADMIN_PREFERENCE_UNSET,
        UserAdminPreference.preferAdmin => hcore.AdminPreference.ADMIN_PREFERENCE_PREFER_ADMIN,
        UserAdminPreference.preferNoAdmin => hcore.AdminPreference.ADMIN_PREFERENCE_PREFER_NO_ADMIN,
      },
    );

    final dialogs = ref.read(dialogNotifierProvider.notifier);
    var useAdminBg = false;
    var stripPrivileged = false;
    var needsElevation = false;

    switch (decision.decision) {
      case hcore.AdminBgServiceDecision.ADMIN_BG_SERVICE_NO:
        useAdminBg = false;
        // preferNoAdmin already decided in Go; still strip privileged features for this run.
        if (pref == UserAdminPreference.preferNoAdmin && decision.adminNeededProxies.isNotEmpty) {
          stripPrivileged = true;
        }
      case hcore.AdminBgServiceDecision.ADMIN_BG_SERVICE_ALREADY_CONNECTED:
        useAdminBg = true;
      case hcore.AdminBgServiceDecision.ADMIN_BG_SERVICE_NEEDS_ADMIN:
        if (options.enableTun && pref == UserAdminPreference.unset) {
          final choice = await dialogs.showVpnAdminBgService();
          _vpnChoiceShown = true;
          if (choice == VpnAdminBgDialogResult.switchToSystemProxy) return _switchToSystemProxy(profile);
          if (choice != VpnAdminBgDialogResult.connectWithAdmin) {
            throw const ConnectionFailure.missingPrivilege();
          }
        }
        useAdminBg = true;
        needsElevation = true;
      case hcore.AdminBgServiceDecision.ADMIN_BG_SERVICE_OPTIONAL_PROXY_NEED_ADMIN:
        final (choice, neverAsk) = await dialogs.showProxyAdminBgService(proxies: decision.adminNeededProxies);
        if (choice == ProxyAdminBgDialogResult.cancel) {
          throw const ConnectionFailure.missingPrivilege();
        }
        if (choice == ProxyAdminBgDialogResult.runAsAdmin) {
          useAdminBg = true;
          needsElevation = true;
          if (neverAsk) {
            await _persistAdminPreference(profile, UserAdminPreference.preferAdmin);
          }
        } else {
          stripPrivileged = true;
          if (neverAsk) {
            await _persistAdminPreference(profile, UserAdminPreference.preferNoAdmin);
          }
        }
      default:
        useAdminBg = false;
    }

    core.useAdminBgService = useAdminBg;
    // the waiting dialog belongs to VPN mode only; a proxy mode that needs the service just shows
    // the system's own prompt
    core.wrapAdminElevation = needsElevation && options.enableTun
        ? (work) async {
            try {
              final ok = await dialogs.runWhileVpnAdminWaiting(work);
              if (!ok) _adminRefused = true;
              return ok;
            } on AdminPermissionRefused {
              _adminRefused = true;
              rethrow;
            }
          }
        : null;

    if (stripPrivileged) {
      final stripped = options.copyWith(tlsTricks: options.tlsTricks.copyWith(mixedSniCase: false));
      _configOptionsSnapshot = stripped;
      final optionsResult = await singbox.changeOptions(stripped).run();
      optionsResult.match((error) => throw ConnectionFailure.unexpected(error), (_) {});
    } else if (useAdminBg) {
      // Re-apply so setOptions sees useAdminBgService.
      final optionsResult = await singbox.changeOptions(options).run();
      optionsResult.match((error) => throw ConnectionFailure.unexpected(error), (_) {});
    }
  }

  /// macOS unsigned builds: root TunnelService / admin_bgservice. Consent before the password prompt.
  Future<void> _prepareMacosAdminBgService(ProfileEntity profile, SingboxConfigOption options) async {
    final core = singbox.core;
    if (core is! CoreInterfaceMacOS) return;
    // the App Store build never asks for root, whatever the native side reports
    if (Release.read() == Release.appStore) return;
    // Network Extension builds do not use the admin password install path.
    if (!core.tunnelServiceAvailable || !options.enableTun) return;

    final dialogs = ref.read(dialogNotifierProvider.notifier);
    final pref = profile.userOverride?.adminPreference ?? UserAdminPreference.unset;

    if (core.tunnelServiceReady) return;

    // Refusing the password prompt, or stopping the wait for it, goes back to the choice.
    while (true) {
      if (pref == UserAdminPreference.unset) {
        final choice = await dialogs.showVpnAdminBgService();
        if (choice == VpnAdminBgDialogResult.switchToSystemProxy) return _switchToSystemProxy(profile);
        if (choice != VpnAdminBgDialogResult.connectWithAdmin) {
          throw const ConnectionFailure.missingPrivilege();
        }
      }
      if (await _installMacosAdminBgService(core, dialogs)) return;
      // no choice to go back to: the profile always asks for administrator permission
      if (pref != UserAdminPreference.unset) throw const ConnectionFailure.missingPrivilege();
      loggy.info("administrator permission was not given, offering the choice again");
    }
  }

  /// Installs the macOS tunnel service behind the password prompt: true once installed, false when
  /// the user refused the prompt or stopped waiting for it.
  Future<bool> _installMacosAdminBgService(CoreInterfaceMacOS core, DialogNotifier dialogs) async {
    try {
      if (await dialogs.runWhileVpnAdminWaiting(core.installAdminBgService())) return true;
      try {
        await core.stop();
      } catch (_) {}
      return false;
    } catch (error) {
      final message = error.toString().toLowerCase();
      if (message.contains('cancel') || message.contains('permission') || message.contains('denied')) return false;
      throw ConnectionFailure.unexpected(error);
    }
  }

  /// The user chose the system proxy over asking for an administrator: it becomes the service mode,
  /// and this connect goes on in it. The connection is not running yet, so the change starts no
  /// reconnect of its own.
  Future<void> _switchToSystemProxy(ProfileEntity profile) async {
    loggy.info("switching to system proxy mode instead of asking for administrator");
    await ref.read(ConfigOptions.serviceMode.notifier).update(ServiceMode.systemProxy);
    (await applyConfigOption(profile).run()).match((failure) => throw failure, (_) {});
    final t = ref.read(translationsProvider).requireValue;
    ref.read(inAppNotificationControllerProvider).showInfoToast(t.dialogs.adminBgService.vpnNeedsAdmin.switched);
    await _prepareAdminBgService(profile);
  }

  Future<void> _persistAdminPreference(ProfileEntity profile, UserAdminPreference preference) async {
    final override = (profile.userOverride ?? const UserOverride()).copyWith(adminPreference: preference);
    final updated = profile.copyWith(userOverride: override);
    final profiles = ref.read(profileRepositoryProvider).requireValue;
    final raw = await profiles.getRawConfig(profile.id).run();
    await raw.match(
      (l) {
        loggy.warning('could not persist admin preference: $l');
      },
      (content) async {
        final result = await profiles.offlineUpdate(updated, content).run();
        result.match((l) => loggy.warning('could not persist admin preference: $l'), (_) {});
      },
    );
  }

  @override
  TaskEither<ConnectionFailure, Unit> disconnect() => singbox.stop().mapLeft(UnexpectedConnectionFailure.new);

  static String _serviceMode(SingboxConfigOption options) =>
      options.routerMode ? 'router' : (options.enableTun ? 'vpn' : (options.setSystemProxy ? 'system-proxy' : 'proxy'));

  /// Windows and Linux: the core runs in this process for proxy modes and in admin_bgservice for
  /// VPN, so a new service mode moves it. A hot reload would only change the core already running
  /// (proxy → VPN removed the system proxy and started no TUN), so the connection is stopped and
  /// made again, which also asks for admin consent.
  @override
  TaskEither<ConnectionFailure, Unit> reconnect(ProfileEntity activeProfile, bool disableMemoryLimit) {
    final before = _configOptionsSnapshot;
    return applyConfigOption(activeProfile).flatMap((_) {
      final after = _configOptionsSnapshot;
      if (singbox.core is CoreInterfaceDesktopTun &&
          before != null &&
          after != null &&
          _serviceMode(before) != _serviceMode(after)) {
        loggy.info("service mode changed from ${_serviceMode(before)} to ${_serviceMode(after)}, reconnecting");
        return disconnect().flatMap((_) => connect(activeProfile, disableMemoryLimit));
      }
      // hot reload when possible, restart otherwise
      return singbox
          .reload(profilePathResolver.file(activeProfile.id).path, activeProfile.name, disableMemoryLimit)
          .mapLeft(UnexpectedConnectionFailure.new);
    });
  }

  @visibleForTesting
  TaskEither<ConnectionFailure, Unit> applyConfigOption(ProfileEntity prof) =>
      TaskEither.fromEither(configOptionRepository.fullOptionsOverrided(prof.profileOverride()))
          .mapLeft((l) => ConnectionFailure.invalidConfigOption(null, l))
          .flatMap(
            (overridedOptions) => TaskEither.tryCatch(() async {
              if (!overridedOptions.chainStatus.isOff()) {
                final isWarpLicenseAgreed = ref.read(Preferences.warpConsentGiven) == true;
                final isWarpEnabled = [
                  overridedOptions.unblocker.mode,
                  overridedOptions.extraSecurity.mode,
                ].any((key) => ChainMode.fromKey(key)?.isWarp() ?? false);
                if (!isWarpLicenseAgreed && isWarpEnabled) {
                  final isAgreed = await ref.read(dialogNotifierProvider.notifier).showWarpLicense();
                  if (isAgreed == true) {
                    await ref.read(Preferences.warpConsentGiven.notifier).update(true);
                    // return (await applyConfigOption(prof).run()).match((l) => throw l, (_) => unit);
                  } else {
                    throw const MissingWarpLicense();
                  }
                }

                final isPsiphonLicenseAgreed = ref.read(Preferences.psiphonConsentGiven) == true;
                final isPsiphonEnabled = [
                  overridedOptions.unblocker.mode,
                  overridedOptions.extraSecurity.mode,
                ].any((key) => ChainMode.fromKey(key)?.isPsiphon() ?? false);
                if (!isPsiphonLicenseAgreed && isPsiphonEnabled) {
                  final isAgreed = await ref.read(dialogNotifierProvider.notifier).showPsiphonLicense();
                  if (isAgreed == true) {
                    await ref.read(Preferences.psiphonConsentGiven.notifier).update(true);
                  } else {
                    throw const MissingPsiphonLicense();
                  }
                }
              }

              _configOptionsSnapshot = overridedOptions;
              final optionsResult = await singbox.changeOptions(overridedOptions).run();
              optionsResult.match((error) => throw ConnectionFailure.unexpected(error), (_) {});
              return unit;
            }, (err, st) => err is ConnectionFailure ? err : ConnectionFailure.unexpected(err, st)),
          );
}
